package com.example.jarvis

import android.Manifest
import android.app.*
import android.content.*
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Bundle
import android.provider.Settings
import android.speech.RecognizerIntent
import android.speech.tts.TextToSpeech
import android.telephony.SmsManager
import android.widget.*
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import java.util.*

class MainActivity : AppCompatActivity(), TextToSpeech.OnInitListener {
    private lateinit var status: TextView
    private lateinit var log: TextView
    private lateinit var tts: TextToSpeech
    private lateinit var jarvis: JarvisEngine

    private val speechLauncher =
        registerForActivityResult(ActivityResultContracts.StartActivityForResult()) { r ->
            val text = r.data?.getStringArrayListExtra(RecognizerIntent.EXTRA_RESULTS)?.firstOrNull()
            if (!text.isNullOrBlank()) handle(text)
        }

    private val permissionLauncher =
        registerForActivityResult(ActivityResultContracts.RequestMultiplePermissions()) { }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(buildUi())
        tts = TextToSpeech(this, this)
        jarvis = JarvisEngine(this) { speak(it) }
        permissionLauncher.launch(arrayOf(
            Manifest.permission.RECORD_AUDIO,
            Manifest.permission.CALL_PHONE,
            Manifest.permission.SEND_SMS,
            Manifest.permission.READ_CONTACTS,
            Manifest.permission.POST_NOTIFICATIONS
        ))
    }

    private fun buildUi(): LinearLayout {
        val box = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(32, 48, 32, 32)
        }
        status = TextView(this).apply { text = "JARVIS is ready"; textSize = 24f }
        log = TextView(this).apply { text = "Say a command…"; textSize = 17f; setPadding(0, 24, 0, 24) }
        val listen = Button(this).apply {
            text = "🎙 TALK TO JARVIS"
            setOnClickListener { listen() }
        }
        val notification = Button(this).apply {
            text = "Enable notification reading"
            setOnClickListener {
                startActivity(Intent("android.settings.ACTION_NOTIFICATION_LISTENER_SETTINGS"))
            }
        }
        box.addView(status); box.addView(log); box.addView(listen); box.addView(notification)
        return box
    }

    private fun listen() {
        val i = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
            putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
            putExtra(RecognizerIntent.EXTRA_LANGUAGE, Locale.getDefault())
            putExtra(RecognizerIntent.EXTRA_PROMPT, "Yes, sir?")
        }
        speechLauncher.launch(i)
    }

    private fun handle(command: String) {
        log.text = "You: $command"
        jarvis.execute(command)
    }

    private fun speak(text: String) {
        runOnUiThread {
            status.text = "JARVIS: $text"
            log.append("\nJARVIS: $text")
            tts.speak(text, TextToSpeech.QUEUE_FLUSH, null, "jarvis")
        }
    }

    override fun onInit(status: Int) {
        if (status == TextToSpeech.SUCCESS) tts.language = Locale.US
    }

    override fun onDestroy() {
        tts.stop(); tts.shutdown(); super.onDestroy()
    }
}

class JarvisEngine(
    private val c: Context,
    private val reply: (String) -> Unit
) {
    fun execute(raw: String) {
        val q = raw.trim()
        val x = q.lowercase(Locale.getDefault())

        when {
            x.startsWith("open ") -> openApp(q.substringAfter(" ").trim())
            x.contains("youtube") -> openPackage("com.google.android.youtube", "YouTube")
            x.contains("whatsapp") -> openPackage("com.whatsapp", "WhatsApp")
            x.contains("camera") -> c.startActivity(Intent("android.media.action.IMAGE_CAPTURE").addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
            x.contains("google") || x.contains("search") ->
                search(q.replace(Regex("(?i)google|search|for"), " ").trim())
            x.startsWith("call ") -> call(q.substringAfter(" ").trim())
            x.startsWith("sms ") || x.startsWith("message ") -> smsHelp(q)
            x.contains("remind") || x.contains("alarm") -> reminderHelp(q)
            x.contains("music") -> openPackage("com.spotify.music", "Spotify")
            x.contains("map") || x.contains("location") -> maps(q)
            x.contains("battery") -> battery()
            x.contains("time") -> reply("The time is " + java.text.SimpleDateFormat("hh:mm a", Locale.getDefault()).format(Date()))
            x.contains("hello") || x.contains("jarvis") -> reply("Yes, sir. I am ready.")
            else -> reply("I understood: $q. For full AI conversation, connect an AI backend in JarvisAi.kt.")
        }
    }

    private fun openApp(name: String) {
        val p = when {
            name.contains("whatsapp") -> "com.whatsapp"
            name.contains("youtube") -> "com.google.android.youtube"
            name.contains("chrome") -> "com.android.chrome"
            name.contains("spotify") -> "com.spotify.music"
            name.contains("camera") -> null
            else -> null
        }
        if (p != null) openPackage(p, name) else reply("I don't know that app yet. Add its package name to JarvisEngine.")
    }

    private fun openPackage(pkg: String, label: String) {
        val i = c.packageManager.getLaunchIntentForPackage(pkg)
        if (i != null) c.startActivity(i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
        else reply("$label is not installed.")
    }

    private fun search(query: String) {
        val i = Intent(Intent.ACTION_VIEW, Uri.parse("https://www.google.com/search?q=" + Uri.encode(query)))
        c.startActivity(i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
        reply("Searching the web.")
    }

    private fun maps(query: String) {
        val i = Intent(Intent.ACTION_VIEW, Uri.parse("geo:0,0?q=" + Uri.encode(query)))
        c.startActivity(i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
    }

    private fun call(numberOrName: String) {
        val uri = Uri.parse("tel:" + Uri.encode(numberOrName))
        c.startActivity(Intent(Intent.ACTION_CALL, uri).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
        reply("Calling $numberOrName.")
    }

    private fun smsHelp(q: String) {
        reply("For safety, the first version opens the SMS composer so you can review the recipient and message before sending.")
        val body = q.substringAfter(" ", "")
        val i = Intent(Intent.ACTION_SENDTO, Uri.parse("smsto:")).apply {
            putExtra("sms_body", body)
            addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        }
        c.startActivity(i)
    }

    private fun reminderHelp(q: String) {
        val am = c.getSystemService(Context.ALARM_SERVICE) as AlarmManager
        val pi = PendingIntent.getActivity(
            c, 100, Intent(c, MainActivity::class.java),
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )
        val at = System.currentTimeMillis() + 60_000
        am.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, at, pi)
        reply("I created a one-minute test reminder. We can add natural-language date and time parsing next.")
    }

    private fun battery() {
        val bm = c.getSystemService(Context.BATTERY_SERVICE) as android.os.BatteryManager
        val p = bm.getIntProperty(android.os.BatteryManager.BATTERY_PROPERTY_CAPACITY)
        reply("Battery is $p percent.")
    }
}

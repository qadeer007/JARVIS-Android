package com.example.jarvis

import android.service.notification.NotificationListenerService
import android.service.notification.StatusBarNotification

class JarvisNotificationListener : NotificationListenerService() {
    override fun onNotificationPosted(sbn: StatusBarNotification) {
        // Notifications can be forwarded to a local/remote AI layer here.
        // Do not silently send notification contents to a server without user consent.
    }
}

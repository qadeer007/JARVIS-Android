# JARVIS Android — first working build

This is a real Android starter project for a voice-controlled assistant.

## Included
- Voice input using Android Speech Recognizer
- Text-to-speech responses
- Open YouTube / WhatsApp / Chrome / Spotify / Camera
- Google web search
- Phone call intent
- SMS composer with user review
- Maps intent
- Battery and time queries
- Notification-listener service skeleton
- Permission handling
- A clean place (`JarvisEngine`) to add more commands and an AI backend

## Important
Android does not allow an app to perform literally every action silently. Calls, SMS, notifications, accessibility, background microphone use and other capabilities are permission-controlled.

## Build
Open this folder in Android Studio, let Gradle sync, then run on an Android phone.

For a production version, add:
1. Always-on/foreground voice trigger (where supported by the device/Android version)
2. Contact-name resolution
3. Natural-language reminder parser
4. WhatsApp actions using supported intents/automation
5. AI backend (keep API keys off the APK)
6. Accessibility service for user-approved UI automation
7. Secure local memory/database
8. Settings screen and command history

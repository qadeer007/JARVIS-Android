# JARVIS — Phone-only APK build

This project can be built from a phone using GitHub Actions; a PC is not required for the build.

1. Create/sign in to a GitHub account.
2. Create a new repository (for example `JARVIS-Android`).
3. Upload the contents of this project to the repository, keeping the `.github/workflows/build-apk.yml` file.
4. Open the repository's **Actions** tab and run **Build JARVIS APK** (or push to `main`).
5. When the workflow finishes, open the run and download the **JARVIS-debug-apk** artifact.
6. Extract the artifact and install `app-debug.apk` on the Vivo Y100.

Important: this is a debug build of the current starter project, not yet the final full JARVIS assistant. Android permissions and security restrictions still apply.
